package com.example.demo.mapper;
import com.example.demo.entity.Userinfo;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserMapper {

    int reg(Userinfo userinfo);
    //这个方法是进行注册的
    // 更优的写法，建议去传对象
}
