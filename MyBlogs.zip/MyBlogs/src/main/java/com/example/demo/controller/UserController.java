package com.example.demo.controller;


import com.example.demo.common.AjaxResult;
import com.example.demo.entity.Userinfo;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
//这是一个注册功能的后端

@RestController
@RequestMapping("/user")
public class UserController{
    @Autowired
    private UserService userService;

    @RequestMapping("reg")
    public AjaxResult reg(Userinfo userinfo){
        //非空效验和参数有效性效验
        //也可能绕过前端的代码直接来一个非法的请求
        //请求不只有一种方式
        if(userinfo==null || !StringUtils.hasLength(userinfo.getUsername()) ||
                  !StringUtils.hasLength(userinfo.getPassword())){
            return AjaxResult.fail(-1,"非法参数");


        }
        return AjaxResult.success(userService.reg(userinfo));


    }



}







